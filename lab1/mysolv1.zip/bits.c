/* 
 * CS:APP Data Lab 
 * 
 * <Please put your name and userid here>
 * 
 * bits.c - Source file with your solutions to the Lab.
 *          This is the file you will hand in to your instructor.
 *
 * WARNING: Do not include the <stdio.h> header; it confuses the dlc
 * compiler. You can still use printf for debugging without including
 * <stdio.h>, although you might get a compiler warning. In general,
 * it's not good practice to ignore compiler warnings, but in this
 * case it's OK.  
 */

#if 0
/*
 * Instructions to Students:
 *
 * STEP 1: Read the following instructions carefully.
 */

You will provide your solution to the Data Lab by
editing the collection of functions in this source file.

INTEGER CODING RULES:
 
  Replace the "return" statement in each function with one
  or more lines of C code that implements the function. Your code 
  must conform to the following style:
 
  int Funct(arg1, arg2, ...) {
      /* brief description of how your implementation works */
      int var1 = Expr1;
      ...
      int varM = ExprM;

      varJ = ExprJ;
      ...
      varN = ExprN;
      return ExprR;
  }

  Each "Expr" is an expression using ONLY the following:
  1. Integer constants 0 through 255 (0xFF), inclusive. You are
      not allowed to use big constants such as 0xffffffff.
  2. Function arguments and local variables (no global variables).
  3. Unary integer operations ! ~
  4. Binary integer operations & ^ | + << >>
    
  Some of the problems restrict the set of allowed operators even further.
  Each "Expr" may consist of multiple operators. You are not restricted to
  one operator per line.

  You are expressly forbidden to:
  1. Use any control constructs such as if, do, while, for, switch, etc.
  2. Define or use any macros.
  3. Define any additional functions in this file.
  4. Call any functions.
  5. Use any other operations, such as &&, ||, -, or ?:
  6. Use any form of casting.
  7. Use any data type other than int.  This implies that you
     cannot use arrays, structs, or unions.

 
  You may assume that your machine:
  1. Uses 2s complement, 32-bit representations of integers.
  2. Performs right shifts arithmetically.
  3. Has unpredictable behavior when shifting an integer by more
     than the word size.

EXAMPLES OF ACCEPTABLE CODING STYLE:
  /*
   * pow2plus1 - returns 2^x + 1, where 0 <= x <= 31
   */
  int pow2plus1(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     return (1 << x) + 1;
  }

  /*
   * pow2plus4 - returns 2^x + 4, where 0 <= x <= 31
   */
  int pow2plus4(int x) {
     /* exploit ability of shifts to compute powers of 2 */
     int result = (1 << x);
     result += 4;
     return result;
  }

FLOATING POINT CODING RULES

For the problems that require you to implent floating-point operations,
the coding rules are less strict.  You are allowed to use looping and
conditional control.  You are allowed to use both ints and unsigneds.
You can use arbitrary integer and unsigned constants.

You are expressly forbidden to:
  1. Define or use any macros.
  2. Define any additional functions in this file.
  3. Call any functions.
  4. Use any form of casting.
  5. Use any data type other than int or unsigned.  This means that you
     cannot use arrays, structs, or unions.
  6. Use any floating point data types, operations, or constants.


NOTES:
  1. Use the dlc (data lab checker) compiler (described in the handout) to 
     check the legality of your solutions.
  2. Each function has a maximum number of operators (! ~ & ^ | + << >>)
     that you are allowed to use for your implementation of the function. 
     The max operator count is checked by dlc. Note that '=' is not 
     counted; you may use as many of these as you want without penalty.
  3. Use the btest test harness to check your functions for correctness.
  4. Use the BDD checker to formally verify your functions
  5. The maximum number of ops for each function is given in the
     header comment for each function. If there are any inconsistencies 
     between the maximum ops in the writeup and in this file, consider
     this file the authoritative source.

/*
 * STEP 2: Modify the following functions according the coding rules.
 * 
 *   IMPORTANT. TO AVOID GRADING SURPRISES:
 *   1. Use the dlc compiler to check that your solutions conform
 *      to the coding rules.
 *   2. Use the BDD checker to formally verify that your solutions produce 
 *      the correct answers.
 */


#endif
/* Copyright (C) 1991-2014 Free Software Foundation, Inc.
   This file is part of the GNU C Library.

   The GNU C Library is free software; you can redistribute it and/or
   modify it under the terms of the GNU Lesser General Public
   License as published by the Free Software Foundation; either
   version 2.1 of the License, or (at your option) any later version.

   The GNU C Library is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
   Lesser General Public License for more details.

   You should have received a copy of the GNU Lesser General Public
   License along with the GNU C Library; if not, see
   <http://www.gnu.org/licenses/>.  */
/* This header is separate from features.h so that the compiler can
   include it implicitly at the start of every compilation.  It must
   not itself include <features.h> or any other header that includes
   <features.h> because the implicit include comes before any feature
   test macros that may be defined in a source file before it first
   explicitly includes a system header.  GCC knows the name of this
   header in order to preinclude it.  */
/* glibc's intent is to support the IEC 559 math functionality, real
   and complex.  If the GCC (4.9 and later) predefined macros
   specifying compiler intent are available, use them to determine
   whether the overall intent is to support these features; otherwise,
   presume an older compiler has intent to support these features and
   define these macros by default.  */
/* wchar_t uses ISO/IEC 10646 (2nd ed., published 2011-03-15) /
   Unicode 6.0.  */
/* We do not support C11 <threads.h>.  */
/* 
 *   lsbZero - set 0 to the least significant bit of x 
 *   Example: lsbZero(0x87654321) = 0x87654320
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 5
 *   Rating: 1
 */
int lsbZero(int x) {
	//实现功能：将LSB置0
  //思路：先左移一位，然后右移一位
  x>>=1;//左移一位，把LSB移出去
  x<<=1;//右移一位，则LSB自动补0
  return x;
}
/* 
 * byteNot - bit-inversion to byte n from word x  
 *   Bytes numbered from 0 (LSB) to 3 (MSB)
 *   Examples: getByteNot(0x12345678,1) = 0x1234A978
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 6
 *   Rating: 2
 */
int byteNot(int x, int n) {
  //实现功能：将x的第n个字节取反，LSB属于0字节
  //思路：与0异或是其本身，与1异或即取反，先取要取反的字节，然后与0xff异或
  int y;
  y=0xff;//一个字节8位，需要八位1进行异或
  n<<=3;//一个字节8位，左移3次相当于×8，计算第n个字节的所需要移动的位数
  y<<=n;//将y左移n位就是移到需要取反的字节处
  return x^y;//异或取反
}
/* 
 *   byteXor - compare the nth byte of x and y, if it is same, return 0, if not, return 1

 *   example: byteXor(0x12345678, 0x87654321, 1) = 1

 *			  byteXor(0x12345678, 0x87344321, 2) = 0
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 2 
 */
int byteXor(int x, int y, int n) {
  //功能：比较x和y的第n个字节，LSB属于0字节，不同返回1，相同返回0
  //思路：先取两数的第n个字节，然后异或（同0异1），再取反下返回
  n<<=3;//每个字节8位，左移3位，相当于乘8
  x>>=n;//将x的低n位全部移除
  y>>=n;//将y的低n位全部移除
  x=x&(0xff);//取当前字节，将高位置0
  y=y&(0xff);
  return !!(x^y);//因为返回需要的是逻辑值，两次取非从而获得0 1逻辑值
}
/* 
 *   logicalAnd - x && y
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 3 
 */
int logicalAnd(int x, int y) {
  //功能：实现逻辑与
  //思路：逻辑与是两个都不为0才为1，先将x y的通过取非获得逻辑值，然后进行按位或，最后取非返回逻辑值
  //相当于运用了德摩根律进行变换
  return !(!x|!y);
}
/* 
 *   logicalOr - x || y
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 3 
 */
int logicalOr(int x, int y) {
  //功能：实现逻辑或
  //思路：同样的运用德摩根律，先通过取非获取逻辑值，然后进行按位与，最后取非返回逻辑值
  return !(!x&!y);
}
/* 
 * rotateLeft - Rotate x to the left by n
 *   Can assume that 0 <= n <= 31
 *   Examples: rotateLeft(0x87654321,4) = 0x76543218
 *   Legal ops: ~ & ^ | + << >> !
 *   Max ops: 25
 *   Rating: 3 
 */
int rotateLeft(int x, int n) {
  //功能:将x循环左移n位
  //思路:将左移n位与右移（32-n）位的数相加即可，
  //需要将左移n位后的数的低n位自动为0，而右移（32-n）位的高n位需要人为保证全部为0
  //引入中间变量t，t的高32-n位全是0，而其他位全是1，这样与右移后的x按位与即可
  //32-n 需要变成补码运用+操作
  //然后二者进行按位与操作
  int t;//中间变量
  //t=~((0xffffffff)<<n);//将32位的ffff右移n位后取反得到中间变量，0xffffffff不合法
  t=~(((1<<31)>>31)<<n);//将1左移31位，然后右移31位变成0xffffffff，然后左移n位再求反
  x=((x>>(32+(~n+1)))&t)+(x<<n);//右移32-n位与t按位与从而将高32-n位置0，然后与左移n位的相加
  return x;
}
/*
 * parityCheck - returns 1 if x contains an odd number of 1's
 *   Examples: parityCheck(5) = 0, parityCheck(7) = 1
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 4
 */
int parityCheck(int x) {
  //功能：若x有奇数个1，则返回1；否则返回0
  //思路：类似二分法的思路，每次将高一半位与低一半位进行异或操作
  //根据异或同0异1的特性，变为0说明是一对1，未变为0的继续高一半 低一半异或
  //最后只剩下一位，如果是奇数个就是1，如果是偶数个最后剩下的一位就是0
  x^=x>>16;//将高16位与低16位进行异或,消去部分偶数个1,结果变成了16位
  x^=x>>8;//将高8位与低8位进行异或,消去部分偶数个1,结果变成了8位
  x^=x>>4;//将高4位与低4位进行异或,消去部分偶数个1,结果变成了4位
  x^=x>>2;//将高2位与低2位进行异或,消去部分偶数个1,结果变成了2位
  x^=x>>1;//将高1位与低1位进行异或,消去部分偶数个1,结果变成了1位
  return x&1;//最后要返回的是逻辑值，与1进行按位与
}
/*
 * mul2OK - Determine if can compute 2*x without overflow
 *   Examples: mul2OK(0x30000000) = 1
 *             mul2OK(0x40000000) = 0
 *         
 *   Legal ops: ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 2
 */
int mul2OK(int x) {
  //功能：计算2×x 不溢出则返回1，否则返回0
  //溢出主要看31位和30位是否相同，如果不同则溢出返回1，相同就不溢出返回0
  int m;
  int n;
  m=(x>>31)&1;//取第31位
  n=(x>>30)&1;//取第30位
  
  return !(m^n);
}
/*
 * mult3div2 - multiplies by 3/2 rounding toward 0,
 *   Should exactly duplicate effect of C expression (x*3/2),
 *   including overflow behavior.
 *   Examples: mult3div2(11) = 16
 *             mult3div2(-9) = -13
 *             mult3div2(1073741824) = -536870912(overflow)
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 12
 *   Rating: 2
 */
int mult3div2(int x) {
  //功能：计算（x*3）/2,朝0方向取整,式子变成x+x/2
  //思路：将乘除法变成移位操作，朝0取整的话需要对不能整除的负数移位后+1操作，负数的符号位就用来作为+1操作的标志
  x=x+(x<<1);
  x=(x>>1)+(((x>>31)&1)&(((x<<31)>>31)&1));//当最高位与最低位相同的时候要+1
  return x;
}
/* 
 * subOK - Determine if can compute x-y without overflow
 *   Example: subOK(0x80000000,0x80000000) = 1,
 *            subOK(0x80000000,0x70000000) = 0, 
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 20
 *   Rating: 3
 */
int subOK(int x, int y) {
  //计算x-y,如果不溢出，则返回1，否则返回0
  //思路：溢出情况为正-负=负，负-正=正
  //综上两种情况可以归纳为当x,y符号位不同，x-y的符号位与x不同的时候，发生溢出
  int m;
  int n;
  m=(x>>31)&1;//获取m的符号位
  n=(y>>31)&1;//获取y的符号位
  x=((x+(~y+1))>>31)&1;//获取x-y的符号位
  return !((m^n)&(m^x));
}
/* 
 * absVal - absolute value of x
 *   Example: absVal(-1) = 1.
 *   You may assume -TMax <= x <= TMax
 *   Legal ops: ! ~ & ^ | + << >>
 *   Max ops: 10
 *   Rating: 4
 */
int absVal(int x) {
  //求x的绝对值
  //思路：符号位为1代表负数，只需要取反后+1，就变成正数了
  return (~(x>>31)&x)+((x>>31)&(~x+1));//符号位为0即为正数，输出本身即可
}
/* 
 * float_abs - Return bit-level equivalent of absolute value of f for
 *   floating point argument f.
 *   Both the argument and result are passed as unsigned int's, but
 *   they are to be interpreted as the bit-level representations of
 *   single-precision floating point values.
 *   When argument is NaN, return argument..
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 10
 *   Rating: 2
 */
unsigned float_abs(unsigned uf) {
  //功能：返回浮点数的’uf'的二进制表示，当输入参数位NaN时，返回NaN
  //------------上述为pdf任务书表述错误，亲测，大坑！！！
  //功能：返回浮点数的绝对值等位二进制，同时对NaN返回NaN
  //思路：浮点数的符号位与尾数是分开存放的，在最高位，只需将最高位置0即可
  //返回之前要判断是否为NaN
  int x;
  x=uf&(~(1<<31));
  if(x>0x7f800000)//NaN为7f800000，阶码全为1，尾数为0
     return uf;
  return x;
}
/* 
 * float_f2i - Return bit-level equivalent of expression (int) f
 *   for floating point argument f.
 *   Argument is passed as unsigned int, but
 *   it is to be interpreted as the bit-level representation of a
 *   single-precision floating point value.
 *   Anything out of range (including NaN and infinity) should return
 *   0x80000000u.
 *   Legal ops: Any integer/unsigned operations incl. ||, &&. also if, while
 *   Max ops: 30
 *   Rating: 4
 */
int float_f2i(unsigned uf) {
  //返回浮点数‘f’的强制转换‘(int)f’表示
  //思路：强制转换分NaN,和正负数情况进行讨论
  int num=0x80000000;
  int x=(uf&0x007fffff)^0x00800000;//取尾数
  int t;
  t=(uf&0x7f800000)>>23;//取阶码
  if(t>158)//阶码向上溢出
     return num;
  if(t<127)//阶码向下溢出
    return 0;
  if(((uf>>31)&1)==1){//负数情况
    if(t>150)//阶超过了22，需要尾数左移
      return ~(x<<(t-150))+1;
    return ~(x>>(150-t))+1;
}
  else//正数情况
  if(t>150)//阶码超过22
    return x<<(t-150);
  return x>>(150-t);
}
